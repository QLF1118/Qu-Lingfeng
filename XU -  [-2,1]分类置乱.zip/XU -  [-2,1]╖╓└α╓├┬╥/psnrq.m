clear;
im=imread('myfig2.JPG');
%im=rgb2gray(img);
figure(1);
imshow(im)
title('orignal image'); 
im2=imread('myfig.JPG');
%im=rgb2gray(img);
figure(2);
imshow(im2)
title('orignal2 image'); 
[m,n]=size(im);

sss=0;
for i=1:m
    for j=1:n
      sss=sss+(double(im(i,j))-double(im2(i,j)))^2;  
    end
end
MSE=sss/(m*n);
PSNR=10*log10(255^2/MSE);