function  [extrab,recovery]=recover2_Xu(embed,L1_C,key,Tn,Tp,w_l)
% �Ӽ�������ȡ����,�ָ�ͼ��embedΪ���ܵļ���ͼ��,Tn��TpΪ��ֵ,keyΪ������Կ��L1_CΪλ�þ���extrabΪ��ȡ�����ܱ�����Ϣ��recoveryΪ�ָ���ԭʼͼ��.
 [m,n]=size(embed);
   for i=1:m/2-1         
       for j=1:n/2-1
          pre_1(i,j)=embed(2*i,2*j);
         pre_2(i,j)=embed(2*i,2*(j+1)-1);
         pre_3(i,j)=embed(2*(i+1)-1,2*j);
           if pre_1(i,j)>128||  pre_1(i,j)==128
               ex_4(i,j)=pre_1(i,j)-128;
           else
               ex_4(i,j)=-pre_1(i,j);
           end
            if pre_2(i,j)>128||  pre_2(i,j)==128
              ex_5(i,j)=pre_2(i,j)-128;
           else
               ex_5(i,j)=-pre_2(i,j);
           end
            if pre_3(i,j)>128||  pre_3(i,j)==128
               ex_6(i,j)=pre_3(i,j)-128;
           else
               ex_6(i,j)=-pre_3(i,j);
            end

       end
   end
     L2=mydecode(L1_C);
    
%������ȡ
 index=0;
     e_index=0; 
     for i=1:m/2-1                         %�ָ�λ��1�Ĳ�������ȡ������Ϣ
         for j=1:n/2-1
            if (ex_4(i,j)>2*Tn && ex_4(i,j)<2*Tp+1)|| ex_4(i,j)==2*Tn || ex_4(i,j)==2*Tp+1 
                e_index =  e_index+1;
                if e_index<w_l||e_index==w_l
              extrab(e_index)=mod(ex_4(i,j),2);
              re_4(i,j)=floor(ex_4(i,j)/2);
                else
                     re_4(i,j)=ex_4(i,j);
                end
           elseif  ex_4(i,j)>2*Tp+1
                      re_4(i,j)=ex_4(i,j)-Tp-1;
           elseif     ex_4(i,j)<2*Tn
                         re_4(i,j)=ex_4(i,j)-Tn;
           end 
         end
     end
     for i=1:m/2-1                       %�ָ�λ��2�Ĳ�������ȡ������Ϣ
         for j=1:n/2-1
            if (ex_5(i,j)>2*Tn && ex_5(i,j)<2*Tp+1)|| ex_5(i,j)==2*Tn || ex_5(i,j)==2*Tp+1  
                e_index =  e_index+1;
                if e_index<w_l||e_index==w_l
              extrab(e_index)=mod(ex_5(i,j),2);
              re_5(i,j)=floor(ex_5(i,j)/2);
                else
                     re_5(i,j)=ex_5(i,j);
                end
           elseif  ex_5(i,j)>2*Tp+1
                      re_5(i,j)=ex_5(i,j)-Tp-1;
           elseif     ex_5(i,j)<2*Tn
                         re_5(i,j)=ex_5(i,j)-Tn;
           end 
         end
     end
      for i=1:m/2-1           %�ָ�λ��2�Ĳ�������ȡ������Ϣ.
         for j=1:n/2-1
            if (ex_6(i,j)>2*Tn && ex_6(i,j)<2*Tp+1)|| ex_6(i,j)==2*Tn || ex_6(i,j)==2*Tp+1  
                e_index =  e_index+1;
                 if e_index<w_l||e_index==w_l
              extrab(e_index)=mod(ex_6(i,j),2);
              re_6(i,j)=floor(ex_6(i,j)/2);
                 else 
                      re_6(i,j)=ex_6(i,j);
                 end
           elseif  ex_6(i,j)>2*Tp+1
                      re_6(i,j)=ex_6(i,j)-Tp-1;
           elseif     ex_6(i,j)<2*Tn
                         re_6(i,j)=ex_6(i,j)-Tn;
           end 
         end
      end
 %�������ؽ���
for i = 1:1:m/2
        for j = 1:1:n/2
            embed_low(i,j) = embed(2*i-1,2*j-1);
        end
    end
   for k1=1:8                      %�Բ������ؽ���
  rand('state',key(k1));
  randombits{k1}=rand(m/2,n/2)<0.5;
  randombits{k1}=double(randombits{k1});
end

%��ȡλ
for k2=1:8
  de_p{k2}=bitget(embed_low,k2);
end 
%��λ���
for k3=1:8
decrypted_1{k3}=bitxor(randombits{k3},de_p{k3});
end
%���ɽ���ͼ��
decrypted_s=zeros(m/2,n/2);
for k=1:8
decrypted_s=decrypted_s+decrypted_1{k}*(2^(k-1));
end
  decrypted=embed;      
    rand('state',key(9));                  %����α������Էǲ����Ĳ������ؽ���
 random11=fix((125-2*Tp+1)*rand(m/2-1,n/2-1));   
  rand('state',key(10));
 random12=fix((125-2*Tp+1)*rand(m/2-1,n/2-1));   
   rand('state',key(11));
 random13=fix((125-2*Tp+1)*rand(m/2-1,n/2-1)); 
   rand('state',key(12));
  random21=fix((126+2*Tn+1)*rand(m/2-1,n/2-1));
     rand('state',key(13));
  random22=fix((126+2*Tn+1)*rand(m/2-1,n/2-1));
     rand('state',key(14));
  random23=fix((126+2*Tn+1)*rand(m/2-1,n/2-1));
    for i = 1:m/2-1                           %��λ��1�Ĳ���������.
        for j = 1:n/2-1
            index=index+1;
           if (re_4(i,j)>Tn &&re_4(i,j)<Tp)||re_4(i,j)==Tn || re_4(i,j)==Tp
               de_4(i,j)=re_4(i,j);
           elseif  (re_4(i,j)>Tp+1 &&re_4(i,j)<126-Tp)||re_4(i,j)==Tp+1 || re_4(i,j)==126-Tp
                      de_4(i,j)=mod((re_4(i,j)-(Tp+1))-random11(i,j),127-2*(Tp+1)+1)+(Tp+1);
           elseif      (re_4(i,j)>-127-Tn &&re_4(i,j)<Tn-1)||re_4(i,j)==-127-Tn || re_4(i,j)==Tn-1
                        de_4(i,j)=-mod(-(re_4(i,j)-(Tn-1))-random21(i,j),127+2*Tn)+(Tn-1);
           end
           if  L2(index)==1
               if de_4(i,j)<0
                   de_4(i,j)=de_4(i,j)-127-Tn;
               elseif de_4(i,j)>0
                    de_4(i,j)=de_4(i,j)+(127-(Tp+1));
               end
           end
        end
    end
    for i = 1:m/2-1                            %��λ��2�Ĳ���������.
        for j = 1:n/2-1
            index=index+1;
           if (re_5(i,j)>Tn &&re_5(i,j)<Tp)||re_5(i,j)==Tn || re_5(i,j)==Tp
               de_5(i,j)=re_5(i,j);
           elseif  (re_5(i,j)>Tp+1 &&re_5(i,j)<126-Tp)||re_5(i,j)==Tp+1 || re_5(i,j)==126-Tp
                      de_5(i,j)=mod((re_5(i,j)-(Tp+1))-random12(i,j),127-2*(Tp+1)+1)+(Tp+1);
           elseif      (re_5(i,j)>-127-Tn &&re_5(i,j)<Tn-1)||re_5(i,j)==-127-Tn || re_5(i,j)==Tn-1
                        de_5(i,j)=-mod(-(re_5(i,j)-(Tn-1))-random22(i,j),127+2*Tn)+(Tn-1);
           end
           if  L2(index)==1
               if de_5(i,j)<0
                   de_5(i,j)=de_5(i,j)-127-Tn;
               elseif de_5(i,j)>0
                    de_5(i,j)=de_5(i,j)+(127-(Tp+1));
               end
           end
        end
    end
          for i = 1:m/2-1                           
        for j = 1:n/2-1
            index=index+1;
           if (re_6(i,j)>Tn &&re_6(i,j)<Tp)||re_6(i,j)==Tn || re_6(i,j)==Tp
               de_6(i,j)=re_6(i,j);
           elseif  (re_6(i,j)>Tp+1 &&re_6(i,j)<126-Tp)||re_6(i,j)==Tp+1 || re_6(i,j)==126-Tp
                      de_6(i,j)=mod((re_6(i,j)-(Tp+1))-random13(i,j),127-2*(Tp+1)+1)+(Tp+1);
           elseif      (re_6(i,j)>-127-Tn &&re_6(i,j)<Tn-1)||re_6(i,j)==-127-Tn || re_6(i,j)==Tn-1
                        de_6(i,j)=-mod(-(re_6(i,j)-(Tn-1))-random23(i,j),127+2*Tn)+(Tn-1);
           end
           if  L2(index)==1
               if de_6(i,j)<0
                   de_6(i,j)=de_6(i,j)-127-Tn;
               elseif de_6(i,j)>0
                    de_6(i,j)=de_6(i,j)+(127-(Tp+1));
               end
           end
        end
          end 
       
    for i=1:m/2-1             %�����ܺ�ĸ����ֲ��������������.
       for j=1:n/2-1       
decrypted(2*i,2*j)=de_4(i,j);
decrypted(2*i,2*(j+1)-1)=de_5(i,j);
decrypted(2*(i+1)-1,2*j)=de_6(i,j);
       end
    end
   for i=1:m/2
       for j=1:n/2
          decrypted(2*i-1,2*j-1) = decrypted_s(i,j);         
       end
   end
   recovery=decrypted;
   Ie1=decrypted;
    for i = 2:2:m-2                             %����λ��1�Ĳ���ֵ��ԭʼֵ
        for j = 2:2:n-2
           x_45 = (decrypted_s(i/2,j/2+1) + decrypted_s(i/2+1,j/2))/2;
           x_135 = (decrypted_s(i/2,j/2) + decrypted_s(i/2+1,j/2+1))/2;
           u = (decrypted_s(i/2,j/2+1) + decrypted_s(i/2+1,j/2)+decrypted_s(i/2,j/2) + decrypted_s(i/2+1,j/2+1))/4;
           delta_45 = (decrypted_s(i/2,j/2+1)-u)^2+(x_45-u)^2+(decrypted_s(i/2+1,j/2) -u)^2;
           delta_45 = delta_45/3;
           delta_135 = (decrypted_s(i/2,j/2)-u)^2+(x_135-u)^2+(decrypted_s(i/2+1,j/2+1) -u)^2;
           delta_135 = delta_135/3;
           w_45 = delta_135/(delta_45+delta_135+0.001);
           w_135 = 1-w_45;
           Ie1(i,j) =floor(x_45*w_45+w_135*x_135);  
            recovery(i,j) =  Ie1(i,j)+decrypted(i,j);
        end
    end   
    for i = 1:1:m/2-1                                   %����λ��2�Ĳ���ֵ��ԭʼֵ
        for j = 2:1:n/2
            x_0 = (Ie1(2*i,2*j)+Ie1(2*i,2*j-2))/2;
            x_90 = (decrypted_s(i,j) + decrypted_s(i+1,j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (Ie1(2*i,2*j)-u)^2+(Ie1(2*i,2*j-2)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (decrypted_s(i,j)-u)^2 + (decrypted_s(i+1,j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie1(2*i,2*j-1) = floor(x_0*w_0 + x_90*w_90);
             recovery(2*i,2*j-1) = Ie1(2*i,2*j-1)+decrypted(2*i,2*j-1);
        end
    end
    for i = 2:1:m/2
        for j = 1:1:n/2-1
            x_0 = (decrypted_s(i,j)+decrypted_s(i,j+1))/2;
            x_90 = (Ie1(2*i,2*j) + Ie1(2*i-2,2*j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (decrypted_s(i,j)-u)^2+(decrypted_s(i,j+1)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (Ie1(2*i,2*j)-u)^2 + (Ie1(2*i-2,2*j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie1(2*i-1,2*j) = floor(x_0*w_0 + x_90*w_90);
            recovery(2*i-1,2*j)  = Ie1(2*i-1,2*j)+decrypted(2*i-1,2*j);
        end
    end
