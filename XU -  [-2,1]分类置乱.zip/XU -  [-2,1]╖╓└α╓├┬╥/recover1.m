function  [extrab,recovery]=recover1(embed,L1_C,key,Tn,Tp,w_l)
% �ӽ�������ȡ���ݲ��ָ�ͼ��,embedΪ���ܵļ���ͼ��,Tn��TpΪ��ֵ,keyΪ������Կ��L1_CΪλ�þ���extrabΪ��ȡ�����ܱ�����Ϣ��recoveryΪ�ָ���ԭʼͼ��.
%% ֱ�ӽ���ͼ��.
 [m,n]=size(embed);
 L2=mydecode(L1_C);     
  for i=1:m/2-1         
       for j=1:n/2-1
          pre_1(i,j)=embed(2*i,2*j);
         pre_2(i,j)=embed(2*i,2*(j+1)-1);
         pre_3(i,j)=embed(2*(i+1)-1,2*j);
           if pre_1(i,j)>128||  pre_1(i,j)==128
               ex_4(i,j)=pre_1(i,j)-128;
           else
               ex_4(i,j)=-pre_1(i,j);
           end
            if pre_2(i,j)>128||  pre_2(i,j)==128
              ex_5(i,j)=pre_2(i,j)-128;
           else
               ex_5(i,j)=-pre_2(i,j);
           end
            if pre_3(i,j)>128||  pre_3(i,j)==128
               ex_6(i,j)=pre_3(i,j)-128;
           else
               ex_6(i,j)=-pre_3(i,j);
            end
       end
  end
     index=0;
     e_index=0; 
 %�������ؽ���
for i = 1:1:m/2
        for j = 1:1:n/2
            embed_low(i,j) = embed(2*i-1,2*j-1);
        end
end
%��ȡλ
for k2=1:8
  de_p{k2}=bitget(embed_low,k2);
end 
for k1=1:8                      %�Բ������ؽ���
  rand('state',key(k1));
  randombits{k1}=rand(m/2,n/2)<0.5;
  randombits{k1}=double(randombits{k1});
end
%��λ���
for k3=1:8
decrypted_1{k3}=bitxor(randombits{k3},de_p{k3});
end
%���ɽ���ͼ��
decrypted_s=zeros(m/2,n/2);
for k=1:8
decrypted_s=decrypted_s+decrypted_1{k}*(2^(k-1));
end 
  decrypted=embed;     
  rand('state',key(9));                  %����α������Էǲ����Ĳ������ؽ���
 random11=fix((125-2*Tp+1)*rand(m/2-1,n/2-1));   
  rand('state',key(10));
 random12=fix((125-2*Tp+1)*rand(m/2-1,n/2-1));   
   rand('state',key(11));
 random13=fix((125-2*Tp+1)*rand(m/2-1,n/2-1)); 
   rand('state',key(12));
  random21=fix((126+2*Tn+1)*rand(m/2-1,n/2-1));
     rand('state',key(13));
  random22=fix((126+2*Tn+1)*rand(m/2-1,n/2-1));
     rand('state',key(14));
  random23=fix((126+2*Tn+1)*rand(m/2-1,n/2-1));
    for i = 1:m/2-1                          %��λ��1�Ĳ���������.
        for j = 1:n/2-1
            index=index+1;
           if (ex_4(i,j)>2*Tn &&ex_4(i,j)<2*Tp+1)||ex_4(i,j)==2*Tn || ex_4(i,j)==2*Tp+1   
               de_4(i,j)=ex_4(i,j);
           elseif  ex_4(i,j)>2*Tp+1 
                      de_4(i,j)=mod((ex_4(i,j)-2*(Tp+1))-random11(i,j),127-2*(Tp+1)+1)+2*(Tp+1);
           elseif      ex_4(i,j)<2*Tn
                        de_4(i,j)=-mod(-(ex_4(i,j)-(2*Tn-1))-random21(i,j),127+2*Tn)+(2*Tn-1);
           end
           if  L2(index)==1
               if de_4(i,j)<0
                   de_4(i,j)=de_4(i,j)-127-Tn;
               elseif de_4(i,j)>0
                    de_4(i,j)=de_4(i,j)+(127-(Tp+1));
               end
           end
        end
    end
     for i = 1:m/2-1                          %��λ��2�Ĳ���������.
        for j = 1:n/2-1
            index=index+1;
           if (ex_5(i,j)>2*Tn &&ex_5(i,j)<2*Tp+1)||ex_5(i,j)==2*Tn || ex_5(i,j)==2*Tp+1    
               de_5(i,j)=ex_5(i,j);
           elseif  ex_5(i,j)>2*Tp+1 
                      de_5(i,j)=mod((ex_5(i,j)-2*(Tp+1))-random12(i,j),127-2*(Tp+1)+1)+2*(Tp+1);
           elseif      ex_5(i,j)<2*Tn
                        de_5(i,j)=-mod(-(ex_5(i,j)-(2*Tn-1))-random22(i,j),127+2*Tn)+(2*Tn-1);
           end
           if  L2(index)==1
               if de_5(i,j)<0
                   de_5(i,j)=de_5(i,j)-127-Tn;
               elseif de_5(i,j)>0
                    de_5(i,j)=de_5(i,j)+(127-(Tp+1));
               end
           end
        end
    end
   
         for i = 1:m/2-1                          %��λ��2�Ĳ���������.
        for j = 1:n/2-1
            index=index+1;
           if (ex_6(i,j)>2*Tn &&ex_6(i,j)<2*Tp+1)||ex_6(i,j)==2*Tn || ex_6(i,j)==2*Tp+1   
               de_6(i,j)=ex_6(i,j);
           elseif  ex_6(i,j)>2*Tp+1 
                      de_6(i,j)=mod((ex_6(i,j)-2*(Tp+1))-random13(i,j),127-2*(Tp+1)+1)+2*(Tp+1);
           elseif      ex_6(i,j)<2*Tn
                        de_6(i,j)=-mod(-(ex_6(i,j)-(2*Tn-1))-random23(i,j),127+2*Tn)+(2*Tn-1);
           end
           if  L2(index)==1
               if de_6(i,j)<0
                   de_6(i,j)=de_6(i,j)-127-Tn;
               elseif de_6(i,j)>0
                    de_6(i,j)=de_6(i,j)+(127-(Tp+1));
               end
           end
        end
    end
       
    for i=1:m/2-1           %�����ܺ�ĸ����ֲ����������������.
       for j=1:n/2-1        
decrypted(2*i,2*j)=de_4(i,j);
decrypted(2*i,2*(j+1)-1)=de_5(i,j);
decrypted(2*(i+1)-1,2*j)=de_6(i,j);
       end
    end
   for i=1:m/2
       for j=1:n/2
          decrypted(2*i-1,2*j-1) = decrypted_s(i,j);         
       end
   end
   recovery_mark=decrypted;
   Ie1=decrypted;
   L3_index=0;
    for i = 2:2:m-2                             %����λ��1�Ĳ���ֵ�ͽ���ֵ
        for j = 2:2:n-2
           x_45 = (decrypted_s(i/2,j/2+1) + decrypted_s(i/2+1,j/2))/2;
           x_135 = (decrypted_s(i/2,j/2) + decrypted_s(i/2+1,j/2+1))/2;
           u = (decrypted_s(i/2,j/2+1) + decrypted_s(i/2+1,j/2)+decrypted_s(i/2,j/2) + decrypted_s(i/2+1,j/2+1))/4;
           delta_45 = (decrypted_s(i/2,j/2+1)-u)^2+(x_45-u)^2+(decrypted_s(i/2+1,j/2) -u)^2;
           delta_45 = delta_45/3;
           delta_135 = (decrypted_s(i/2,j/2)-u)^2+(x_135-u)^2+(decrypted_s(i/2+1,j/2+1) -u)^2;
           delta_135 = delta_135/3;
           w_45 = delta_135/(delta_45+delta_135+0.001);
           w_135 = 1-w_45;
           Ie1(i,j) =floor(x_45*w_45+w_135*x_135);  
            recovery_mark(i,j) =  Ie1(i,j)+decrypted(i,j);
            L3_index= L3_index+1;
            if  (recovery_mark(i,j)>256 && recovery_mark(i,j)<256+Tp)|| recovery_mark(i,j)==256 || recovery_mark(i,j)==(256+Tp)
                L3(L3_index)=1;
                recovery_mark(i,j)=recovery_mark(i,j)-(Tp+1);
            elseif (recovery_mark(i,j)>Tn && recovery_mark(i,j)<-1)|| recovery_mark(i,j)==Tn|| recovery_mark(i,j)==-1
                L3(L3_index)=1;
                recovery_mark(i,j)=recovery_mark(i,j)-Tn;
            else 
                 L3(L3_index)=0;        
        end
        end   
    end
    for i = 1:1:m/2-1                                  %����λ��2�Ĳ���ֵ�ͽ���ֵ
        for j = 2:1:n/2
            x_0 = (Ie1(2*i,2*j)+Ie1(2*i,2*j-2))/2;
            x_90 = (decrypted_s(i,j) + decrypted_s(i+1,j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (Ie1(2*i,2*j)-u)^2+(Ie1(2*i,2*j-2)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (decrypted_s(i,j)-u)^2 + (decrypted_s(i+1,j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie1(2*i,2*j-1) = floor(x_0*w_0 + x_90*w_90);
             recovery_mark(2*i,2*j-1) = Ie1(2*i,2*j-1)+decrypted(2*i,2*j-1);
              L3_index= L3_index+1;
            if  (recovery_mark(2*i,2*j-1)>256 && recovery_mark(2*i,2*j-1)<256+Tp)|| recovery_mark(2*i,2*j-1)==256 || recovery_mark(2*i,2*j-1)==(256+Tp)
                L3(L3_index)=1;
                recovery_mark(2*i,2*j-1)=recovery_mark(2*i,2*j-1)-(Tp+1);
            elseif (recovery_mark(2*i,2*j-1)>Tn && recovery_mark(2*i,2*j-1)<-1)|| recovery_mark(2*i,2*j-1)==Tn|| recovery_mark(2*i,2*j-1)==-1
                L3(L3_index)=1;
                recovery_mark(2*i,2*j-1)=recovery_mark(2*i,2*j-1)-Tn;
            else 
                 L3(L3_index)=0;        
        end
        end
    end
    for i = 2:1:m/2
        for j = 1:1:n/2-1
            x_0 = (decrypted_s(i,j)+decrypted_s(i,j+1))/2;
            x_90 = (Ie1(2*i,2*j) + Ie1(2*i-2,2*j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (decrypted_s(i,j)-u)^2+(decrypted_s(i,j+1)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (Ie1(2*i,2*j)-u)^2 + (Ie1(2*i-2,2*j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie1(2*i-1,2*j) = floor(x_0*w_0 + x_90*w_90);
            recovery_mark(2*i-1,2*j)  = Ie1(2*i-1,2*j)+decrypted(2*i-1,2*j);
             L3_index= L3_index+1;
            if  (recovery_mark(2*i-1,2*j)>256 && recovery_mark(2*i-1,2*j)<256+Tp)|| recovery_mark(2*i-1,2*j)==256 || recovery_mark(2*i-1,2*j)==(256+Tp)
                L3(L3_index)=1;
                recovery_mark(2*i-1,2*j)=recovery_mark(2*i-1,2*j)-(Tp+1);
            elseif (recovery_mark(2*i-1,2*j)>Tn && recovery_mark(2*i-1,2*j)<-1)|| recovery_mark(2*i-1,2*j)==Tn|| recovery_mark(2*i-1,2*j)==-1
                L3(L3_index)=1;
                recovery_mark(2*i-1,2*j)=recovery_mark(2*i-1,2*j)-Tn;
            else 
                 L3(L3_index)=0;        
        end
        end
    end
%% �ӽ���ͼ������ȡ���ݲ��ָ�ԭʼͼ��
 for i = 1:1:m/2
        for j = 1:1:n/2
            recovery_mark_low(i,j) = recovery_mark(2*i-1,2*j-1);      %��������
        end
 end
    Ie2=recovery_mark;
     recovery=recovery_mark;
     recovery_mark_2=zeros(512,512);       %�洢��ȡ���ݺ�Ĺ��ƴ���.
     index=0;
     error_index=0;
     e_index=0;
 for i = 2:2:m-2                             %��ȡ���ܱ��أ�����λ��1�Ĳ���ֵ��ԭʼֵ
        for j = 2:2:n-2
           x_45 = (recovery_mark_low(i/2,j/2+1) + recovery_mark_low(i/2+1,j/2))/2;
           x_135 = (recovery_mark_low(i/2,j/2) + recovery_mark_low(i/2+1,j/2+1))/2;
           u = (recovery_mark_low(i/2,j/2+1) + recovery_mark_low(i/2+1,j/2)+recovery_mark_low(i/2,j/2) + recovery_mark_low(i/2+1,j/2+1))/4;
           delta_45 = (recovery_mark_low(i/2,j/2+1)-u)^2+(x_45-u)^2+(recovery_mark_low(i/2+1,j/2) -u)^2;
           delta_45 = delta_45/3;
           delta_135 = (recovery_mark_low(i/2,j/2)-u)^2+(x_135-u)^2+(recovery_mark_low(i/2+1,j/2+1) -u)^2;
           delta_135 = delta_135/3;
           w_45 = delta_135/(delta_45+delta_135+0.001);
           w_135 = 1-w_45;
           Ie2(i,j) =floor(x_45*w_45+w_135*x_135);  
           ee =   recovery_mark(i,j)-Ie2(i,j);      %��Ƕ�����ݵĲ������
           index= index+1;
           if L3(index)==1
            if  (recovery_mark(i,j)>256-(Tp+1) && recovery_mark(i,j)<255) || recovery_mark(i,j)==256-(Tp+1)|| recovery_mark(i,j)==255
              ee=ee+(Tp+1);
            elseif (recovery_mark(i,j)>0 && recovery_mark(i,j)<-1-Tn)|| recovery_mark(i,j)==0|| recovery_mark(i,j)==-1-Tn
                ee=ee+Tn;          
        end
           end  
             if  L2(index)==1                                  %
               if ee<0
                   ee=ee+127+Tn;
               elseif ee>0
                   ee=ee-(127-(Tp+1));
               end
           end
        if (ee>2*Tn && ee<2*Tp+1)|| ee==2*Tn || ee==2*Tp+1   
                e_index =  e_index+1;
                if  e_index<w_l||e_index==w_l
              extrab(e_index)=mod(ee,2);
              recovery_mark_2(i,j)=floor(ee/2);
                else 
                    recovery_mark_2(i,j)=ee;
                end
           elseif ee>2*Tp+1
                      recovery_mark_2(i,j)=ee-Tp-1;
           elseif     ee<2*Tn
                          recovery_mark_2(i,j)=ee-Tn;
           end 
         if  L2(index)==1                                  %
               if recovery_mark_2(i,j)<0
                   recovery_mark_2(i,j)=recovery_mark_2(i,j)-127-Tn;
               elseif recovery_mark_2(i,j)>0
                   recovery_mark_2(i,j)=recovery_mark_2(i,j)+(127-(Tp+1));
               end
           end
           recovery(i,j)=Ie2(i,j)+recovery_mark_2(i,j);
        end
 end
    for i = 1:1:m/2-1                                   %����λ��2�Ĳ���ֵ��ԭʼֵ
        for j = 2:1:n/2
            x_0 = (Ie2(2*i,2*j)+Ie2(2*i,2*j-2))/2;
            x_90 = (recovery_mark_low(i,j) + recovery_mark_low(i+1,j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (Ie2(2*i,2*j)-u)^2+(Ie2(2*i,2*j-2)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (recovery_mark_low(i,j)-u)^2 + (recovery_mark_low(i+1,j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie2(2*i,2*j-1) = floor(x_0*w_0 + x_90*w_90);
             ee =   recovery_mark(2*i,2*j-1)-Ie2(2*i,2*j-1); 
             index= index+1;
             if L3(index)==1
            if  (recovery_mark(2*i,2*j-1)>256-(Tp+1) && recovery_mark(2*i,2*j-1)<255) || recovery_mark(2*i,2*j-1)==256-(Tp+1)|| recovery_mark(2*i,2*j-1)==255
              ee=ee+(Tp+1);
            elseif (recovery_mark(2*i,2*j-1)>0 && recovery_mark(2*i,2*j-1)<-1-Tn)|| recovery_mark(2*i,2*j-1)==0|| recovery_mark(2*i,2*j-1)==-1-Tn
                ee=ee+Tn;            
        end
             end  
           if  L2(index)==1                                  %
               if ee<0
                   ee=ee+127+Tn;
               elseif ee>0
                   ee=ee-(127-(Tp+1));
               end
           end
        if (ee>2*Tn && ee<2*Tp+1)|| ee==2*Tn || ee==2*Tp+1   
                e_index =  e_index+1;
                if e_index<w_l||e_index==w_l
              extrab(e_index)=mod(ee,2);
              recovery_mark_2(2*i,2*j-1)=floor(ee/2);
                else 
                     recovery_mark_2(2*i,2*j-1)=ee;
                end
           elseif ee>2*Tp+1
                      recovery_mark_2(2*i,2*j-1)=ee-Tp-1;
           elseif     ee<2*Tn
                          recovery_mark_2(2*i,2*j-1)=ee-Tn;
        end 
        if  L2(index)==1                                  %
               if recovery_mark_2(2*i,2*j-1)<0
                   recovery_mark_2(2*i,2*j-1)=recovery_mark_2(2*i,2*j-1)-127-Tn;
               elseif recovery_mark_2(2*i,2*j-1)>0
                   recovery_mark_2(2*i,2*j-1)=recovery_mark_2(2*i,2*j-1)+(127-(Tp+1));
               end
           end
           recovery(2*i,2*j-1)=Ie2(2*i,2*j-1)+recovery_mark_2(2*i,2*j-1);
        end
    end
    for i = 2:1:m/2
        for j = 1:1:n/2-1
            x_0 = (recovery_mark_low(i,j)+recovery_mark_low(i,j+1))/2;
            x_90 = (Ie2(2*i,2*j) + Ie2(2*i-2,2*j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (recovery_mark_low(i,j)-u)^2+(recovery_mark_low(i,j+1)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (Ie2(2*i,2*j)-u)^2 + (Ie2(2*i-2,2*j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie2(2*i-1,2*j) = floor(x_0*w_0 + x_90*w_90);
            ee =   recovery_mark(2*i-1,2*j)-Ie2(2*i-1,2*j); 
            index= index+1;
           if L3(index)==1
            if  (recovery_mark(2*i-1,2*j)>256-(Tp+1) && recovery_mark(2*i-1,2*j)<255) || recovery_mark(2*i-1,2*j)==256-(Tp+1)|| recovery_mark(2*i-1,2*j)==255
              ee=ee+(Tp+1);
            elseif (recovery_mark(2*i-1,2*j)>0 && recovery_mark(2*i-1,2*j)<-1-Tn)|| recovery_mark(2*i-1,2*j)==0|| recovery_mark(2*i-1,2*j)==-1-Tn
                ee=ee+Tn;             
        end
           end  
           if  L2(index)==1                                  %
               if ee<0
                   ee=ee+127+Tn;
               elseif ee>0
                   ee=ee-(127-(Tp+1));
               end
           end
        if (ee>2*Tn && ee<2*Tp+1)|| ee==2*Tn || ee==2*Tp+1   
                e_index =  e_index+1;
               if e_index<w_l||e_index==w_l
              extrab(e_index)=mod(ee,2);
              recovery_mark_2(2*i-1,2*j)=floor(ee/2);
               else
                   recovery_mark_2(2*i-1,2*j)=ee;
               end
           elseif ee>2*Tp+1
                      recovery_mark_2(2*i-1,2*j)=ee-Tp-1;
           elseif     ee<2*Tn
                          recovery_mark_2(2*i-1,2*j)=ee-Tn;
        end 
        if  L2(index)==1                                  %
               if recovery_mark_2(2*i-1,2*j)<0
                   recovery_mark_2(2*i-1,2*j)=recovery_mark_2(2*i-1,2*j)-127-Tn;
               elseif recovery_mark_2(2*i-1,2*j)>0
                   recovery_mark_2(2*i-1,2*j)=recovery_mark_2(2*i-1,2*j)+(127-(Tp+1));
               end
           end
           recovery(2*i-1,2*j)=Ie2(2*i-1,2*j)+recovery_mark_2(2*i-1,2*j);
        end
    end
   
