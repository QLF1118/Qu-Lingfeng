function PSNR=psnr(u,v)
[m,n]=size(u);
a=0;
for i=1:m
    for j=1:n
         t(i,j)=u(i,j)-v(i,j);
         a=a+t(i,j)^2;
    end
end
mse=a/(m*n);
PSNR=10*log10(255^2/mse);