function decrypted_image=decryption_Xu(embed,key,Tn,Tp,mm,L1_C,Mm,p,fb)
%�Ժ��ܵļ���ͼ����ָܻ�ԭʼͼ��,embedΪ���ܵļ���ͼ��,Tn��TpΪ��ֵ,keyΪ������Կ��L1_CΪλ�þ���decrypted_imageΪ�ָ�ͼ��.MmΪmap���ȣ�p,fbΪ������λ
 [m,n]=size(embed); 

 de_encrypted=embed;

 img=de_encrypted;
 L2=mydecode(L1_C);

%   capcity=mm*6;
%   real=capcity-m*n; 
for k1=1:8                      %������Կ���������
  rand('state',key(k1));
  randombits{k1}=rand(m,n)<0.5;
  randombits{k1}=double(randombits{k1});
end

 %��ȡλ
for k2=1:8
  original_p{k2}=bitget(img,k2);
end   %��ȡ�������ذ˸�λƽ��
 
         %��λ���
for k3=1:8
encrypted_1{k3}=bitxor(randombits{k3},original_p{k3});
end
%����������ͼ��
de_encrypted_s=zeros(m,n);
for k=1:8
de_encrypted_s=de_encrypted_s+encrypted_1{k}*(2^(k-1));
end 
 AA=de_encrypted_s;
%*************��Ƕ����Ϣλ���㣬��ȡmap��Ϣ��mapλ����*****************
Z=zeros(1,6*mm);
 de_embed=de_encrypted_s;
 [m,n]=size(de_encrypted_s);
 de_img= de_embed(1:mm);%��ȡ�����ܺ�ɱ�����
 x=floor(Mm/mm);
 tt=8-x;
y=mod(Mm,mm);

 nn=ceil(log((Tp-Tn)+1)/log(2));%nn��ʾ�ɱ������в��ɱ�λ��
  capcity=mm*(8-nn);
  real=capcity-Mm; %��ȥmap��ʵ�ʿ�Ƕ��bit��
 for j=1:8
      plane_cell{j}=bitget(de_img,j);
 end
  
 plane_cell{tt}(y+1:mm)=Z(y+1:mm);
%  message=w(mm-y+1:real);
 k=1;kl=1;
for i=8-x-1:-1:(nn+1)
    plane_cell{i}=Z(k:kl*mm);
    k=kl*mm+1;
    kl=kl+1; 
end%���Ƕ��λƽ������

k=1;kl=1;  %��ȡ��Ƕ���ڸ�λ��map��Ϣ
for i=8:-1:8-x+1 %��8 7 6λƽ��Ƕ��map
   map1(k:kl*mm)=plane_cell{i};
    k=kl*mm+1;
    kl=kl+1; 
end
map1(k:Mm)=plane_cell{i-1}(1:y);%map��Ϣ��ȡ��ϣ�

k=1;kl=1;  %map��Ϣλ����
for i=8:-1:8-x+1 %��8 7 6λƽ������
    plane_cell{i}=Z(k:kl*mm);
    k=kl*mm+1;
    kl=kl+1; 
end
plane_cell{i-1}(1:y)=0;%map��Ϣ������ϣ�


de_encrypted_z=zeros(1,mm);
for k=1:8
de_encrypted_z=de_encrypted_z+plane_cell{k}*(2^(k-1));
end%�Կɱ����صĲ������

%*******************������*****************************************
fl=de_encrypted_z;
 
   for i=1:mm
       if fl(i)==0
           f_fl_bm(i)=Tn;
       end
       if fl(i)==1
           f_fl_bm(i)=Tn+1;
       end
       if fl(i)==2
           f_fl_bm(i)=Tn+2;
       end
       if fl(i)==3
           f_fl_bm(i)=Tn+3;
       end
       
       if fl(i)==4
           f_fl_bm(i)=Tn+4;
       end
       if fl(i)==5
           f_fl_bm(i)=Tn+5;
       end
       if fl(i)==6
           f_fl_bm(i)=Tn+6;
       end
       if fl(i)==7
           f_fl_bm(i)=Tn+7;
       end
       if fl(i)==8
           f_fl_bm(i)=Tn+8;
       end
       if fl(i)==9
           f_fl_bm(i)=Tn+9;
       end
       if fl(i)==10
           f_fl_bm(i)=Tn+10;
       end
       if fl(i)==11
           f_fl_bm(i)=Tn+11;
       end
       
       if fl(i)==12
           f_fl_bm(i)=Tn+12;
       end
       if fl(i)==13
           f_fl_bm(i)=Tn+13;
       end
       if fl(i)==14
           f_fl_bm(i)=Tn+14;
       end
       if fl(i)==15
           f_fl_bm(i)=Tn+15;
       end
        if fl(i)==16
           f_fl_bm(i)=Tn+16;
       end
   end
   

%f_f1_bm�������Ŀɱ�����
 AA(1:mm)= f_fl_bm(1:mm);
fl=AA(1:mm);
 f2=AA(mm+1:mm+p);%��ֵ֮��Ĳ�ֵ����
 f3=AA(mm+p+1:mm+p+fb);%��Ե����
 f4=AA(mm+p+fb+1:m*n);%��������
 %***********************************���һָ�************************************
 refl=fl; %�ָ�fl
keyw=123456;
[x1,y1]=size(refl);
RandStream.setGlobalStream(RandStream('mt19937ar','seed',keyw));
RR=randperm(x1*y1);
zrefl=refl;
for i=1:x1*y1
    zrefl(RR(i))=refl(i);
end
AA(1:mm)=zrefl;
f_fl_bm=zrefl;

 ref2=f2; %�ָ�f2
keyw=123456;
[x1,y1]=size(ref2);
RandStream.setGlobalStream(RandStream('mt19937ar','seed',keyw));
RR=randperm(x1*y1);
zref2=ref2;
for i=1:x1*y1
    zref2(RR(i))=ref2(i);
end
f2=zref2;
ref4=f4; %�ָ�f4
keyw=123456;
[x1,y1]=size(ref4);
RandStream.setGlobalStream(RandStream('mt19937ar','seed',keyw));
RR=randperm(x1*y1);
zref4=ref4;
for i=1:x1*y1
    zref4(RR(i))=ref4(i);
end
f4=zref4;
 
%map1=reshape(map1,m,n);%�õ���ȡ��map

%*******************************����map�ָ�λ��*******************************
% q=1;p=1;%q��ʾ���ɱ��������꣬p��ʾ�ɱ���������
re_img(1:n)=f3(1:n);
re_img(2:m,1)=f3(n+1:n+(m-1))';
re_img(m,2:n)=f3(n+(m-1)+1:2*n+m-2);
re_img(2:m-1,n)=f3(2*n+m-1:2*n+2*m-4)';%�ָ���Ե����
g=1; 
for i=3:2:m-1%�ָ���������
      for j=3:2:n-1
         re_img(i,j)=f4(g);
          g=g+1;
      end
  end

k4=1;k5=1;k6=1;
for i=1:m/2-1         %���������ӳ�䵽��Ӧ���أ��ð˱��ر�ʾ��.
       for j=1:n/2-1
          pre_1(i,j)=re_img(2*i,2*j);
    pre_2(i,j)=re_img(2*i,2*(j+1)-1);
pre_3(i,j)=re_img(2*(i+1)-1,2*j);
       end
  end
   for i = 1:m/2-1        %f1 ��ֵ�� f2��ֵ֮��Ĳ�ֵ
        for j = 1:n/2-1
           
           if map1(k4)==0
              pre_1(i,j)=f_fl_bm(k5);
               k4=k4+1;
               k5=k5+1;
           else
              pre_1(i,j)=f2(k6);
               k6=k6+1;
               k4=k4+1;
           
           end
        end
   end
   for i = 1:m/2-1        %��λ��1��ֵ֮��Ĳ������ؽ���ӳ��
        for j = 1:n/2-1
           
         if map1(k4)==0
              pre_2(i,j)=f_fl_bm(k5);
               k4=k4+1;
               k5=k5+1;
           else
              pre_2(i,j)=f2(k6);
               k6=k6+1;
               k4=k4+1;
           
        end
        end
   end
     for i = 1:m/2-1        %
        for j = 1:n/2-1
           
           if map1(k4)==0
              pre_3(i,j)=f_fl_bm(k5);
               k4=k4+1;
               k5=k5+1;
           else
              pre_3(i,j)=f2(k6);
               k6=k6+1;
               k4=k4+1;
           
        end
        end
     end
for i=1:m/2-1         %���������ӳ�䵽��Ӧ���أ��ð˱��ر�ʾ��.
       for j=1:n/2-1
         re_img(2*i,2*j)=pre_1(i,j);
    re_img(2*i,2*(j+1)-1)=pre_2(i,j);
re_img(2*(i+1)-1,2*j)=pre_3(i,j);
       end
  end
   
re_pre=re_img;

 
%***************�ָ�λ�����******************************************************       

%****************�ָ���ֵ��Ĳ�������*****************************************8**
for i=1:m/2-1         %���������ӳ�䵽��Ӧ���أ��ð˱��ر�ʾ��.
       for j=1:n/2-1
          re_pre_4(i,j)=re_pre(2*i,2*j);
    re_pre_5(i,j)=re_pre(2*i,2*(j+1)-1);
re_pre_6(i,j)=re_pre(2*(i+1)-1,2*j);
           
       end
 end
 for i = 1:m/2-1                           
        for j = 1:n/2-1
           
           if (re_pre_5(i,j)>Tn &&re_pre_5(i,j)<Tp)||re_pre_5(i,j)==Tn || re_pre_5(i,j)==Tp
               re_pre_2(i,j)=re_pre_5(i,j);
           elseif  (re_pre_5(i,j)>abs(Tn)+1 &&re_pre_5(i,j)<127)||re_pre_5(i,j)==abs(Tn)+1 || re_pre_5(i,j)==127
                     re_pre_2(i,j)=-re_pre_5(i,j);
          elseif  (re_pre_5(i,j)>128 &&re_pre_5(i,j)<255)||re_pre_5(i,j)==128 || re_pre_5(i,j)==255
                     re_pre_2(i,j)=re_pre_5(i,j)-128;
           end
        end
    end
 for i = 1:m/2-1                           %.
        for j = 1:n/2-1
           
           if (re_pre_6(i,j)>Tn &&re_pre_6(i,j)<Tp)||re_pre_6(i,j)==Tn || re_pre_6(i,j)==Tp
               re_pre_3(i,j)=re_pre_6(i,j);
           elseif  (re_pre_6(i,j)>abs(Tn)+1 &&re_pre_6(i,j)<127)||re_pre_6(i,j)==abs(Tn)+1 || re_pre_6(i,j)==127
                     re_pre_3(i,j)=-re_pre_6(i,j);
           elseif      (re_pre_6(i,j)>128 &&re_pre_6(i,j)<255)||re_pre_6(i,j)==128 || re_pre_6(i,j)==255
                         re_pre_3(i,j)= re_pre_6(i,j)-128;
           end
           
        end
 end
    
 for i = 1:m/2-1                           %.
        for j = 1:n/2-1
           
           if (re_pre_4(i,j)>Tn &&re_pre_4(i,j)<Tp)||re_pre_4(i,j)==Tn || re_pre_4(i,j)==Tp
               re_pre_1(i,j)=re_pre_4(i,j);
           elseif  (re_pre_4(i,j)>abs(Tn)+1 &&re_pre_4(i,j)<127)||re_pre_4(i,j)==abs(Tn)+1 || re_pre_4(i,j)==127
                     re_pre_1(i,j)=-re_pre_4(i,j);
           elseif      (re_pre_4(i,j)>128 &&re_pre_4(i,j)<255)||re_pre_4(i,j)==128 || re_pre_4(i,j)==255
                         re_pre_1(i,j)= re_pre_4(i,j)-128;
           end
           
        end
 end
 
 
for i=1:m/2-1           
       for j=1:n/2-1
           
re_pre(2*i,2*j)=re_pre_1(i,j);
re_pre(2*i,2*(j+1)-1)=re_pre_2(i,j);
re_pre(2*(i+1)-1,2*j)=re_pre_3(i,j);
       end
    end
%******************re_pre�ظ����***********************************************************
%�ָ��γ̱����¼������ֵ****************************************************************
index=0;
for i=1:m/2-1         
       for j=1:n/2-1
          re_pre_4(i,j)=re_pre(2*i,2*j);
    re_pre_5(i,j)=re_pre(2*i,2*(j+1)-1);
re_pre_6(i,j)=re_pre(2*(i+1)-1,2*j);
           
       end
 end
 for i = 1:m/2-1                           %��λ��1�Ĳ���������.
        for j = 1:n/2-1
           index=index+1;
           if  L2(index)==1
               if re_pre_4(i,j)<0
                   re_pre_4(i,j)=re_pre_4(i,j)-127;
               elseif re_pre_4(i,j)>0
                    re_pre_4(i,j)=re_pre_4(i,j)+127;
               end
           end
           
        end
    end
 for i = 1:m/2-1                           %��λ��1�Ĳ���������.
        for j = 1:n/2-1
            index=index+1;
           if  L2(index)==1
               if  re_pre_5(i,j)<0
                    re_pre_5(i,j)= re_pre_5(i,j)-127;
               elseif  re_pre_5(i,j)>0
                     re_pre_5(i,j)= re_pre_5(i,j)+127;
               end 
        end
        end
 end
    
 for i = 1:m/2-1                           %��λ��1�Ĳ���������.
        for j = 1:n/2-1
            index=index+1;
         if  L2(index)==1
               if re_pre_6(i,j)<0
                  re_pre_6(i,j)=re_pre_6(i,j)-127;
               elseif re_pre_6(i,j)>0
                    re_pre_6(i,j)=re_pre_6(i,j)+127;
               end
           end   
  
           
        end
    end
for i=1:m/2-1           
       for j=1:n/2-1
           
re_pre(2*i,2*j)=re_pre_4(i,j);
re_pre(2*i,2*(j+1)-1)=re_pre_5(i,j);
re_pre(2*(i+1)-1,2*j)=re_pre_6(i,j);
       end
    end

%************************************************************************************

for i = 1:1:m/2
        for j = 1:1:n/2
            decrypted_s(i,j) = re_pre(2*i-1,2*j-1);
        end
end
   decrypted=re_pre;
   recovery=re_pre;
   Ie1=re_pre;
    for i = 2:2:m-2                             %����λ��1�Ĳ���ֵ��ԭʼֵ
        for j = 2:2:n-2
           x_45 = (decrypted_s(i/2,j/2+1) + decrypted_s(i/2+1,j/2))/2;
           x_135 = (decrypted_s(i/2,j/2) + decrypted_s(i/2+1,j/2+1))/2;
           u = (decrypted_s(i/2,j/2+1) + decrypted_s(i/2+1,j/2)+decrypted_s(i/2,j/2) + decrypted_s(i/2+1,j/2+1))/4;
           delta_45 = (decrypted_s(i/2,j/2+1)-u)^2+(x_45-u)^2+(decrypted_s(i/2+1,j/2) -u)^2;
           delta_45 = delta_45/3;
           delta_135 = (decrypted_s(i/2,j/2)-u)^2+(x_135-u)^2+(decrypted_s(i/2+1,j/2+1) -u)^2;
           delta_135 = delta_135/3;
           w_45 = delta_135/(delta_45+delta_135+0.001);
           w_135 = 1-w_45;
           Ie1(i,j) =floor(x_45*w_45+w_135*x_135);  
            recovery(i,j) =  Ie1(i,j)+decrypted(i,j);
        end
    end   
    for i = 1:1:m/2-1                                   %����λ��2�Ĳ���ֵ��ԭʼֵ
        for j = 2:1:n/2
            x_0 = (Ie1(2*i,2*j)+Ie1(2*i,2*j-2))/2;
            x_90 = (decrypted_s(i,j) + decrypted_s(i+1,j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (Ie1(2*i,2*j)-u)^2+(Ie1(2*i,2*j-2)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (decrypted_s(i,j)-u)^2 + (decrypted_s(i+1,j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie1(2*i,2*j-1) = floor(x_0*w_0 + x_90*w_90);
             recovery(2*i,2*j-1) = Ie1(2*i,2*j-1)+decrypted(2*i,2*j-1);
        end
    end
    for i = 2:1:m/2
        for j = 1:1:n/2-1
            x_0 = (decrypted_s(i,j)+decrypted_s(i,j+1))/2;
            x_90 = (Ie1(2*i,2*j) + Ie1(2*i-2,2*j))/2;
            u = (x_0+x_90)/2;
            delta_0 = (decrypted_s(i,j)-u)^2+(decrypted_s(i,j+1)-u)^2+(x_0-u)^2;
            delta_0 = delta_0/3;
            delta_90 = (Ie1(2*i,2*j)-u)^2 + (Ie1(2*i-2,2*j)-u)^2 + (x_90-u)^2;
            delta_90 = delta_90/3;
            w_0 = delta_0/(0.001+delta_0+delta_90);
            w_90 = 1-w_0;
            Ie1(2*i-1,2*j) = floor(x_0*w_0 + x_90*w_90);
            recovery(2*i-1,2*j)  = Ie1(2*i-1,2*j)+decrypted(2*i-1,2*j);
        end
    end

    decrypted_image= recovery;
  